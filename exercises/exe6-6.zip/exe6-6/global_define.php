<?php

if (!isset($index_loaded)) {
    die('Direct acces to this file is forbidden');
}

/*
 * this file contains all project contants.
 */
// COMPANY INFO
define('COMPANY_NAME', 'Electronic Scooter inc.');
define('COMPANY_PHONE', '514-234-2334');
define('COMPANY_EMAIL', 'service@electricscooter.com');
define('ADMIN_EMAIL', 'it_admin@electricscooter.com');

 // WEB PAGE INFO
 define('WEB_SITE_NAME', 'ElectronicScooter.com');
 define('PAGE_DEFAULT_TITLE', 'Welcom to ElectricScooter.com!');
 define('PAGE_DEFAULT_DESCRIPTION', 'ElectricScooters.com has the widest selection of scooters, bicycles, new, used, services in montreal');
 define('PAGE_DEFAULT_AUTHOR', 'Gurkirat Singh');
 define('PAGE_DEFAULT_LANG', 'en-CA');
 define('PAGE_DEFAULT_ICON', 'images/my_icon.jpg');
